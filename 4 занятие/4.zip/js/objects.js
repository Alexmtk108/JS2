function sum(...params){
	console.log(params);
}

function evklid(m/*106*/,n/*16*/){
	//console.log(m+ ' % '+ n + '= '+ (m % n));
	if(!(m % n)) return n; // 106 16 = 10
	return evklid(n,m % n);
}

evklid(106,16);

let t = 5; // 120
function fact(f){
	if( f === 1) return f;
	return f * fact(f-1);
}


function foo(a,b){
	a + sum(a,b);
	log(a);
}
function sum(a,b){
	return a+b;
}
function log(test){
	console.log(test);
}

foo(5,5);

/*
CallStack
1 foo
2 sum
3 log
4 console.log
*/

/* Игра флажки */

function exitGame(step){
	if(step == -1){
		return true;
		}	
	return false;
}	
function checkWin(flags){
	if(flags <= 3){
		return true;
	}	
	return false;
}
function validateStep(step){
	if(isNaN(step)) return false;
	return true;
}
function checkStep(step){
	if( (step != 1) && (step != 2) && (step != 3) ){
		return false;
	}
	return true;
}
function changePlayer(player){
	player = !player;
}
function showPlayerStep(player,step){
	if(!player){
		console.log('Игрок 1 походил: ' + step);
	}else{
		console.log('Игрок 2 походил: ' + step);
	}
}
function showFlagsRest(cost){
 	console.log( 'В игре осталось '+ cost +' флагов');
}
function showWinner(player){
	if(!player){
		console.warn('Победил Игрок 1');
	}else{
		console.warn('Победил Игрок 2');
	}
}
function showAlert(type){
	if(type == 'validate'){
		console.error('Не корректный ввод. Введите число');
	}
	if(type == 'check'){
		console.error('Не корректный ввод. Введите число от 1 до 3');
	}
}
function MonsterFlag(flags = 21,player = false){
//	checkStep(step);
	if( checkWin(flags) ) {
		showWinner(player);
		return; 
	}
	let step = prompt('Введите число от 1 до 3') * 1;
	
	if( exitGame(step) ) return;

	if( !validateStep(step) ) {
		showAlert('validate');
		return MonsterFlag(flags,player);
	}
	if( !checkStep(step) ) {
		showAlert('check');
		return MonsterFlag(flags,player);
	}

	let cost = flags-=step;

	changePlayer(player);

	showPlayerStep(player,step);
	showFlagsRest(cost);

	return MonsterFlag(cost,!player);
}



MonsterFlag();







