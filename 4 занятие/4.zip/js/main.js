/*var 
	name = 'Anton',
 	age = 10,
	answer = true;
console.log(name,age,answer);
*/
const PI = 3.14;


let 
	name,
 	age,
	answer;

name = 'Вася';

//console.log(PI, name, age, answer);

let sum;

sum = 2 + 2;
sum = 2 - 2;
sum = 2 / 2;
sum = 2 * 2;

// Операторы сравнения
let a,b,c,d;
a = 2;
b = 3;
c = a == b;
c = a < b;
c = a > b;
c = a >= b;
c = a <= b;

d = 'Привет';

c = a * d; // NaN
c = a / d; // NaN
c = d - a; // NaN
c = d + a; // привет2
c = '2' + a; // 22
c = '2' * a; // 
c = 2 + '+'  + 2; //
c = '233' * 1; // Перевести в число
c = (2 * 'Привет') == (2 * 'Привет');  // false

c = 3 % 2; // Остаток от деления


// Логические

c =  2 + (2 * 2);
c =  3 * (4 / 2);
c =  3 / 4 * 2; 
c = true * 5; // 5
c = true + 5; // 6
c = true + '5'; // true5
c = true * '5'; // 


c = ( 1 > 2) == (2 > 1); 
c = ( 1 > 2) && (2 > 1); 
c = ( 2 > 1) || (2 > 1); 

c = 2 === '2';
c = 3;

// Тернарный оп
(2 < 1) ? c = 'Да' : c= "Нет";

//console.log( c );
typeof 'A'; // string
/**/
let test;
//console.log( 0 == test );
//console.log( false == test );







//let name = 'Вася';
//let name = "Вася";
//let age = '18';
let birthday= 1990;

let out;

out = age * birthday;
//console.log(out); // 2008 || 181990 || 35820

//Вывести треугольник символами *

//*
//**
//***
//****
//*****


let symbol= '*',
	triangle = '';

triangle = symbol+symbol;
//console.log(symbol);
//console.log(symbol+symbol);
//console.log(symbol+symbol+symbol);
///console.log(symbol+symbol+symbol+symbol);
//console.log(symbol+symbol+symbol+symbol+symbol);



 let i = 0;
while(i < 10){
	i = i+1;
	console.log(i); // 0 1 2 3
}


















